
public class Pair {
    public int vertice;
    public int cost;

    public Pair(int vertice, int cost) {
        this.vertice = vertice;
        this.cost = cost;
    }
}
